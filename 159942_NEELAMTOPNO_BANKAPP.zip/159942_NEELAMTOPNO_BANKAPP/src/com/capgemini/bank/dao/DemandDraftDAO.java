package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;


public class DemandDraftDAO implements IDemandDraftDAO {
	private Connection conn=ConnectionProvider.getDBConnection();
	private static final Logger logger=Logger.getLogger(DemandDraftDAO.class);
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt=conn.prepareStatement("INSERT INTO  demand_draft(customer_name, "
					+ "in_favor_of,"
					+ " phone_number,"
					+ "date_of_transaction,"
					+ "dd_amount,"
					+ "dd_commission,"
					+ "dd_description) values(?,?,?,sysdate,?,?,?)");
			pstmt.setString(1, demandDraft.getCustomerName());
			pstmt.setString(2, demandDraft.getInFavorOf());
			pstmt.setString(3, demandDraft.getPhoneNumber());
			pstmt.setDouble(4, demandDraft.getDdAmount());
			pstmt.setDouble(5, demandDraft.getDdCommission());
			pstmt.setString(6, demandDraft.getDdDescription());
			pstmt.executeUpdate();
			
			PreparedStatement pstmt2=conn.prepareStatement("select max(transaction_id) from demand_draft");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();//always open
			int transactionId=rs.getInt(1);
			conn.commit();
			demandDraft.setTransactionId(transactionId);
			return transactionId;
		}
		catch(SQLException e){
			logger.error(e.getMessage()+"  "+e.getCause()+"  "+e.getErrorCode());
			conn.rollback();
			conn.close();
			e.printStackTrace();
			throw e;

			
		}
		
		finally{
			conn.setAutoCommit(true);
		}
		
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException {
		try {
			PreparedStatement pstmt1=conn.prepareStatement("Select * from demand_draft where transaction_Id="+transactionId);
			ResultSet bankingRS=pstmt1.executeQuery();
			if(bankingRS.next()){
				String customerName=bankingRS.getString("customer_name");
				String inFavorOf=bankingRS.getString("in_favor_of");
				String phoneNumber=bankingRS.getString("phone_number");
				String dateOfTransaction=bankingRS.getString("date_of_transaction");
				double ddAmount=bankingRS.getDouble("dd_amount");
				double ddCommission=bankingRS.getDouble("dd_commission");
				String ddDescription=bankingRS.getString("dd_description");
				DemandDraft demandDraft=new DemandDraft( transactionId, customerName,
						inFavorOf, phoneNumber,  dateOfTransaction,
						 ddAmount, ddCommission, ddDescription);
				
				return demandDraft;				
}
		} catch (SQLException e) {
		
			logger.error(e.getMessage()+"  "+e.getCause()+"  "+e.getErrorCode());
			e.printStackTrace();
			conn.rollback();
			conn.close();
			throw e;
		}
		return null;

	}
}

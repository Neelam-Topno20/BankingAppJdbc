package com.capgemini.bank.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;


public class DemandDraftServiceTest {
	
	private static  DemandDraftDAO mockDemandDraftDao;
	private static DemandDraftService demandDraftServices;
	@BeforeClass
	public static void setUpTestEnv() {
		mockDemandDraftDao=EasyMock.mock(DemandDraftDAO.class);
		demandDraftServices=new DemandDraftService(mockDemandDraftDao);
	}

	@Before
	public void setUpTestData() throws SQLException{
		DemandDraft demandDraft=new DemandDraft(10006, "somnath","capgeinee", "9123100565", "13-OCT-2018", 70000, 51, "thanks");
		EasyMock.expect(mockDemandDraftDao.addDemandDraftDetails(demandDraft)).andReturn(10006);
		EasyMock.expect(mockDemandDraftDao.getDemandDraftDetails(10006)).andReturn(demandDraft);
		
	}
	 
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

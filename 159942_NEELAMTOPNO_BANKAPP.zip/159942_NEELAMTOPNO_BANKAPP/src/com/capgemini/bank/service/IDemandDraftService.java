package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exceptions.BankingServicesDownException;
import com.capgemini.bank.exceptions.DdAmountNotValidException;
import com.capgemini.bank.exceptions.DemandDraftDetailsNotFoundException;
import com.capgemini.bank.exceptions.PhoneNumberNotValidException;

public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft)throws DdAmountNotValidException,BankingServicesDownException,PhoneNumberNotValidException;
	DemandDraft getDemandDraftDetails(int transactionId)throws BankingServicesDownException,DemandDraftDetailsNotFoundException;
}
